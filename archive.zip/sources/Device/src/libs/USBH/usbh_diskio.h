#pragma once

#include "ff_gen_drv.h"
#include "usbh_core.h"
#include "usbh_msc.h"

extern const Diskio_drvTypeDef  USBH_Driver;
