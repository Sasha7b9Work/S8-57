#pragma once


class HiPart
{
public:
    
    static void Draw();

    static void WriteCursors();

    static void DrawRightPart();
};
