#include "stdafx.h"
#ifndef WIN32
#include "Osci/Osci.h"
#endif


volatile int i = 0; //-V707
