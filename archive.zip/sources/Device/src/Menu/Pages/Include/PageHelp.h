#pragma once
#include "Menu/MenuItems.h"


class PageHelp
{
public:
    static const PageBase *pointer;
};
