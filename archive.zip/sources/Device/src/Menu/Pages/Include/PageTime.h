#pragma once


class PageTime
{
public:

    static void OnChanged_PeakDet(bool active);

    static void OnChanged_TPos(bool active);

    static const PageBase *pointer;
};
