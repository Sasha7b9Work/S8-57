#pragma once


class PageService
{
public:
    static const PageBase *pointer;
};
