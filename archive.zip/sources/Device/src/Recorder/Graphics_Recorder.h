#pragma once


namespace Recorder
{
    namespace Graphics
    {
        void Update();
    }
}
