#pragma once

#define STEP_RSHIFT 1
#define MAX_VALUE   227
#define MIN_VALUE   27
