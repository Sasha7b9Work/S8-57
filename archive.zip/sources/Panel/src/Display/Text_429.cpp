#include "defines.h"
#include "Text.h"
#include "Painter.h"


int i; //-V707
