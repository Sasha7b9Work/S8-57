#pragma once

#define NOR_MEMORY_ADRESS1       0x60000000U
