#pragma once


#define PWR_REGULATOR_VOLTAGE_SCALE3         3


#define __HAL_PWR_VOLTAGESCALING_CONFIG(x)
