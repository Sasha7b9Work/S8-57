#pragma once


#define GPIO_AF12_FMC           ((uint8_t)0x0C)
