#include "stdafx.h"


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
HAL_StatusTypeDef  FMC_NORSRAM_Timing_Init(FMC_NORSRAM_TypeDef * /*Device*/, FMC_NORSRAM_TimingTypeDef * /*Timing*/, uint32_t /*Bank*/)
{
    return HAL_ERROR;
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
HAL_StatusTypeDef  FMC_NORSRAM_Init(FMC_NORSRAM_TypeDef * /*Device*/, FMC_NORSRAM_InitTypeDef * /*Init*/)
{
    return HAL_ERROR;
}
