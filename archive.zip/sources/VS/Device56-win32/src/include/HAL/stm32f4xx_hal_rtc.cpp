#include "stdafx.h"


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
HAL_StatusTypeDef HAL_RTC_GetTime(RTC_HandleTypeDef * /*hrtc*/, RTC_TimeTypeDef * /*sTime*/, uint32_t /*Format*/)
{
    return HAL_ERROR;
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
HAL_StatusTypeDef HAL_RTC_GetDate(RTC_HandleTypeDef * /*hrtc*/, RTC_DateTypeDef * /*sDate*/, uint32_t /*Format*/)
{
    return HAL_ERROR;
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
HAL_StatusTypeDef HAL_RTC_SetDate(RTC_HandleTypeDef * /*hrtc*/, RTC_DateTypeDef * /*sDate*/, uint32_t /*Format*/)
{
    return HAL_ERROR;
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
HAL_StatusTypeDef HAL_RTC_SetTime(RTC_HandleTypeDef * /*hrtc*/, RTC_TimeTypeDef * /*sTime*/, uint32_t /*Format*/)
{
    return HAL_ERROR;
}
