#pragma once

#ifndef STATUS
#define STATUS BYTE
#endif


/* Results of Disk Functions */
#ifndef DRESULT
typedef enum {
    RES_OK = 0,		/* 0: Successful */
    RES_ERROR,		/* 1: R/W Error */
    RES_WRPRT,		/* 2: Write Protected */
    RES_NOTRDY,		/* 3: Not Ready */
    RES_PARERR		/* 4: Invalid Parameter */
} DRESULT;
#endif
