#pragma once
#include "usbh_core.h"


extern USBH_ClassTypeDef  USBH_msc;
#define USBH_MSC_CLASS    &USBH_msc
